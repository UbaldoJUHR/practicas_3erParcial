import serial
import time

try:
    ser = serial.Serial('COM13', 9600, timeout=1)  # Cambia 'COM3' según tu puerto
    time.sleep(2)  # Espera a que el Arduino reinicie

    while True:
        if ser.in_waiting > 0:
            line = ser.readline().decode('utf-8').rstrip()
            try:
                sensor_value = int(line)
                print(f"Valor del sensor: {sensor_value}")

                if sensor_value > 500:
                    ser.write(b'1\n')  # Enciende el LED
                else:
                    ser.write(b'0\n')  # Apaga el LED
            except ValueError:
                print(f"Dato no válido: {line}")
        time.sleep(0.1)

except serial.SerialException as e:
    print(f"Error de puerto serie: {e}")
except KeyboardInterrupt:
    print("Programa terminado.")
finally:
    if 'ser' in locals() and ser.is_open:
        ser.close()
#Alvarez Rodriguez Jose Eduardo, Hernandez Ramos Jose Ubaldo, Juarez Mayorga Ximena Guadalupe, Montes Rivera Fernanda Marisela, Vazquez Reyna Angel Levi